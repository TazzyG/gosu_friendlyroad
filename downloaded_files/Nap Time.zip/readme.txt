﻿                              Û Û  Û ÛÛÛÛ  ÛÛ
                                ²Û ² ²    ²  ²
                              ± ± ±± ±±±  ±  ±
                              ² ²  ² ²    ²  ²
 ÛÛÛ ÛÛÛ ÛÛÛ                  Û Û  Û Û     ÛÛ                       ÛÛÛ ÛÛÛ ÛÛÛ
 Û±ÛÛÛ ÛÛÛ                                                            ÛÛÛ ÛÛÛ±Û
 ÛÛÚÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄ¿ÛÛ
  Û³                                                                        ³Û
 ÛÛ³                        Composer :: Cleyton R. Xavier                  ³ÛÛ
 Û ³                                                                        ³ Û
 ÛÛ³                           Track :: Nap Time	                   ³ÛÛ
  Û ³                                                                       ³Û
 ÛÛ³                           Alias :: Doppelganger / RyogaKauffman       ³ÛÛ
 Û ³                                                                        ³ Û
 ÛÛ³                         Created :: 1 June 16                          ³ÛÛ
  Û³                                                                        ³Û
 ÛÛ³            Audio Files Included :: WAV     	                   ³ÛÛ
 Û ³                                                                        ³ Û
 ÛÛ³                    Looped Audio :: No                                 ³ÛÛ
  Û³                                                                        ³Û
 ÛÛ³            Stems Files Included :: No                                 ³ÛÛ
 Û ³                                                                        ³ Û
 ÛÛ³                     Sample Rate :: 16-Bit Stereo, 44.1 kHz            ³ÛÛ
  Û³                                                                        ³Û
 ÛÛ³                        Bit Rate :: 320 kbps                           ³ÛÛ
 Û ³                                                                        ³ Û
 ÛÛ³               Main Track Length :: 0:07                               ³ÛÛ
  Û³                                                                        ³Û
 ÛÛ³                      Tempo(BPM) :: ---                                ³ÛÛ
 Û ³                                                                        ³ Û
 ÛÛ³                             Tag :: vgm, Rpg                           ³ÛÛ
  Û³                                                                        ³Û
 Û ³                         License :: CC-BY-SA 4.0                        ³ Û
 ÛÛ³                                                                       ³ÛÛ
 ÛÛÀÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÄÙÛÛ
 Û±ÛÛÛ ÛÛÛ                                                            ÛÛÛ ÛÛÛ±Û
 ÛÛÛ ÛÛÛ ÛÛÛ                                                        ÛÛÛ ÛÛÛ ÛÛÛ
   
                            Û  Û  ÛÛ ÛÛÛÛÛ ÛÛÛÛ ÛÛÛÛ
                            ²² ² ²  ²  ²   ²    ²
                            ± ±± ±  ±  ±   ±±±  ±±±±
                            ²  ² ²  ²  ²   ²       ²
 ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ    Û  Û  ÛÛ   Û   ÛÛÛÛ ÛÛÛÛ    ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ
 Û±ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ                            ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ±Û
 ÛÛ                                                                          ÛÛ
  Û                                                                          Û
 ÛÛ                                                                          ÛÛ
 Û                                                                            Û
 ÛÛ                      Copyright/Attribution Notice                        ÛÛ
 Û                                                                            Û
 ÛÛ  Music by Cleyton R. Xavier - http://opengameart.org/users/doppelganger  ÛÛ
 Û                                                                            Û
 ÛÛ                                   OR                                     ÛÛ
  Û                                                                          Û
 ÛÛ                       Music by Cleyton R. Xavier                         ÛÛ
 Û                         cleytonrxmusic@gmail.com                          Û
 ÛÛ                                                                          ÛÛ
  Û                                                                          Û
 ÛÛ                                                                          ÛÛ
 Û±ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ    ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ±Û
 ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ


 ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛÛ Û  Û ÛÛÛÛ ÛÛÛÛ   Û   ÛÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ
 Û ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ                                    ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ Û
 ÛÛ                                                                          ÛÛ
  Û               If you want to hire me for custom soundtracks,              Û
 ÛÛ           you can contact me by e-mail: cleytonrxmusic@gmail.com         ÛÛ
 Û                If you have any doubt with game audio stuffs,               Û
 ÛÛ           you can contact me as well (:                                  ÛÛ
  Û                        Thank you for your support!                        Û
 ÛÛ                                  Doppel                                  ÛÛ
 Û                                                                            Û
 Û ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ    ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ Û
 ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ ÛÛÛ


                    

                                                                              
